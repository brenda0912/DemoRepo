package selenium.selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.Test;
import java.util.concurrent.TimeUnit;
public class Testing{
    @Test
    
    public static void main(String[] args)
	 {
    	
    	
    	//System.setProperty("webdriver.chrome.driver","/usr/bin/chromedriver");
    	
    	ChromeOptions options = new ChromeOptions();
    	//ChromeDriver driver = new ChromeDriver();
    	
    	options.addArguments("--no-sandbox");
    	options.addArguments("--single-process");
    	options.addArguments("--headless");
    	options.addArguments("--disable-dev-shm-usage");
    	System.setProperty("webdriver.chrome.driver","/usr/bin/chromedriver");
    	ChromeDriver driver = new ChromeDriver();
    	
    	
		//put implicit wait
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.get("http://localhost:84");		
		driver.manage().window().maximize();
		driver.findElement(By.id("About Us")).click();
		String toVerified="This is about page. Lorem Ipsum Dipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.";
		String actual= driver.findElement(By.cssSelector("p")).getText();
		//Assert.assertEquals(actual, toVerified);
		if (actual.equals(toVerified))
			{
			System.out.println("pass");
			}
				else
			{
			System.out.println("Fail");
			}
			driver.close();		
		

	 }
} 